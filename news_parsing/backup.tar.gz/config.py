BOT_TOKEN = "7860144131:AAEzwawng1BJjVJ-RtTwVcYBNzcPsxghF4g"
CHANNEL_ID = -1002712994446
DEEPSEEK_KEY = "sk-0c19f7b4a67943fa9c008063910b9e97"
ADMINS = [ 5225476657] #1621866383, 918713634, 535801213,
# === Настройки для публикации на сайт ===
SITE_LOGIN = "ajlin4277@gmail.com"
SITE_PASSWORD = "Ab123456789"
SITE_URL = "https://api.demo.agrosearch.kz"  # URL формы добавления новости